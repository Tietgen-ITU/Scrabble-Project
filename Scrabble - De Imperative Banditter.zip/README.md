# Scrabble-Project
This is a project for the course Introduction to Functional Programming

## What's been completed:
Multi-player and dictionary - yes
Parsing boards playing on all boards - yes
parallelism - yes
Respect the timeout flag - no
