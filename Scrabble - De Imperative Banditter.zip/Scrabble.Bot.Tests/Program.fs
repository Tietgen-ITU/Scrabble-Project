module Program =

    [<EntryPoint>]
    let main _ = 0
